create extension if not exists pgcrypto;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  brand text not null default 'Romance',
  reference text not null,
  price integer not null check (price >= 0),
  category text not null check (category in ('mujeres', 'hombres', 'ninos')),
  sizes text,
  color text,
  short_note text,
  image_url text not null,
  status text not null default 'published' check (status in ('published', 'hidden')),
  is_new boolean not null default false,
  is_offer boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.products enable row level security;
create policy "Public can read published products" on public.products for select using (status = 'published' or auth.role() = 'authenticated');
create policy "Authenticated admin can insert products" on public.products for insert to authenticated with check (true);
create policy "Authenticated admin can update products" on public.products for update to authenticated using (true) with check (true);
create policy "Authenticated admin can delete products" on public.products for delete to authenticated using (true);

insert into storage.buckets (id, name, public) values ('product-images', 'product-images', true) on conflict (id) do update set public = true;
create policy "Public can view product images" on storage.objects for select using (bucket_id = 'product-images');
create policy "Authenticated admin can upload product images" on storage.objects for insert to authenticated with check (bucket_id = 'product-images');
create policy "Authenticated admin can update product images" on storage.objects for update to authenticated using (bucket_id = 'product-images');
create policy "Authenticated admin can delete product images" on storage.objects for delete to authenticated using (bucket_id = 'product-images');

create or replace function public.set_updated_at() returns trigger language plpgsql as $$ begin new.updated_at = now(); return new; end $$;
drop trigger if exists products_updated_at on public.products;
create trigger products_updated_at before update on public.products for each row execute function public.set_updated_at();
